﻿using Microsoft.AspNetCore.Mvc;
using SynetecAssessmentApi.Dtos;
using SynetecAssessmentApi.Services;
using System.Threading.Tasks;

namespace SynetecAssessmentApi.Controllers
{
    [Route("api/[controller]")]
    public class BonusPoolController : Controller
    {
        private IEmployeeServices _employeeServices;
        public BonusPoolController(IEmployeeServices employeeServices)
        {
            _employeeServices = employeeServices;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            return Ok(await _employeeServices.GetAllEmployees());
        }

        [HttpPost()]
        public async Task<IActionResult> CalculateBonus([FromBody] CalculateBonusDto request)
        {
            if (request != null)
            {
                var bonusPoolCalculatorResult = await _employeeServices.GetEmployeeBonus(request.SelectedEmployeeId, request.TotalBonusPoolAmount);
                if (bonusPoolCalculatorResult != null)
                {
                    return Ok(bonusPoolCalculatorResult);
                }
                else
                {
                    return NotFound("No Employee found");
                }
            }
            else
            {
                return Problem("Error in parameters, both parameters are mandatory");
            }
            
        }
    }
}
