﻿namespace SynetecAssessmentApi.Dtos
{
    public class BonusPoolCalculatorResultDto
    {
        public int Amount { get; set; }
        public EmployeeDto Employee { get; set; }
    }
}
