﻿using Microsoft.EntityFrameworkCore;
using SynetecAssessmentApi.Domain;
using SynetecAssessmentApi.Dtos;
using SynetecAssessmentApi.Persistence;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SynetecAssessmentApi.Services
{
    public class BonusService : IBonusService
    {
        public async Task<int> Calculate(int bonusPoolAmount, int employeeSalary, int totalSalary)
        {
            //calculate the bonus allocation for the employee
            decimal bonusPercentage = 0;
            if (totalSalary > 0)
            { 
                bonusPercentage = (decimal)employeeSalary / (decimal)totalSalary;
            }
            return (int)(bonusPercentage * bonusPoolAmount);
        }
    }
}
