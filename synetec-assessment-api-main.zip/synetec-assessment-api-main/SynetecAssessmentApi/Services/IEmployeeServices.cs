﻿using SynetecAssessmentApi.Dtos;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SynetecAssessmentApi.Services
{
    public interface IEmployeeServices
    {
        Task<IEnumerable<EmployeeDto>> GetAllEmployees();
        EmployeeDto GetEmployeeById(int id);
        int TotalSalary();

        Task<BonusPoolCalculatorResultDto> GetEmployeeBonus(int employeeId, int totalBonusAmount);
    }
}