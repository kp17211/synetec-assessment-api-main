﻿using Microsoft.EntityFrameworkCore;
using SynetecAssessmentApi.Domain;
using SynetecAssessmentApi.Dtos;
using SynetecAssessmentApi.Persistence;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SynetecAssessmentApi.Services
{
    public class EmployeeServices : IEmployeeServices
    {
        private readonly AppDbContext _dbContext;
        private readonly IBonusService _bonusPoolService;

        public EmployeeServices(AppDbContext appDbContext, IBonusService bonusPoolService)
        {
            _dbContext = appDbContext;
            _bonusPoolService = bonusPoolService;
        }

        public async Task<IEnumerable<EmployeeDto>> GetAllEmployees()
        {
            IEnumerable<Employee> employees = _dbContext
                .Employees
                .Include(e => e.Department)
                .ToList();

            List<EmployeeDto> result = new List<EmployeeDto>();

            foreach (var employee in employees)
            {
                result.Add(
                    new EmployeeDto
                    {
                        Fullname = employee.Fullname,
                        JobTitle = employee.JobTitle,
                        Salary = employee.Salary,
                        Department = new DepartmentDto
                        {
                            Title = employee.Department.Title,
                            Description = employee.Department.Description
                        }
                    });
            }

            return result;
        }

        public EmployeeDto GetEmployeeById(int id)
        {
            Employee employee = _dbContext
                .Employees
                .Include(e => e.Department)
                .FirstOrDefault(item => item.Id == id);

            if (employee != null)
            {
                return new EmployeeDto
                {
                    Fullname = employee.Fullname,
                    JobTitle = employee.JobTitle,
                    Salary = employee.Salary,
                    Department = new DepartmentDto
                    {
                        Title = employee.Department.Title,
                        Description = employee.Department.Description
                    }
                };
            }
            else
            {
                return null;
            }

        }

        public int TotalSalary()
        {
            return (int)_dbContext.Employees.Sum(item => item.Salary); 
        }

        public async Task<BonusPoolCalculatorResultDto> GetEmployeeBonus(int employeeId, int totalBonusAmount)
        {
            EmployeeDto employeeDto = GetEmployeeById(employeeId);
            if (employeeDto != null)
            {
                return (new BonusPoolCalculatorResultDto
                {
                    Employee = employeeDto,
                    Amount = await _bonusPoolService.Calculate(totalBonusAmount, employeeDto.Salary, TotalSalary())
                });
            }
            return null;
        }
    }
}
