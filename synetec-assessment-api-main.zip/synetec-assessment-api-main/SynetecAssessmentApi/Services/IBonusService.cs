﻿using System.Threading.Tasks;

namespace SynetecAssessmentApi.Services
{
    public interface IBonusService
    {
        Task<int> Calculate(int bonusPoolAmount, int employeeSalary, int totalSalary);
    }
}