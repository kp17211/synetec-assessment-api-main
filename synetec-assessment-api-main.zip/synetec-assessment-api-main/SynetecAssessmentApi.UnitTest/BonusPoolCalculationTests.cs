using NUnit.Framework;

namespace SynetecAssessmentApi.UnitTest
{
    public class BonusPoolCalculationTests
    {
        private Services.IBonusService _bonusPoolService;

        [SetUp]
        public void Setup()
        {
            _bonusPoolService = new Services.BonusService();
        }

        [Test]
        public async System.Threading.Tasks.Task CalculateBonus_150000TS5000S650000B_Return21666()
        {
            //Arrange
            int totalSalary = 150000;
            int salary = 5000;
            int bonusPool = 650000;

            //Act
            var result = await _bonusPoolService.Calculate(bonusPool, salary, totalSalary);

            //Assert
            Assert.AreEqual(21666,result);
        }

        [Test]
        public async System.Threading.Tasks.Task CalculateBonus_0TS5000S650000B_Return0()
        {
            //Arrange
            int totalSalary = 0;
            int salary = 5000;
            int bonusPool = 650000;

            //Act
            var result = await _bonusPoolService.Calculate(bonusPool, salary, totalSalary);

            //Assert
            Assert.AreEqual(0, result);
        }

        [Test]
        public async System.Threading.Tasks.Task CalculateBonus_150000TS5000S0B_Return0()
        {
            //Arrange
            int totalSalary = 150000;
            int salary = 5000;
            int bonusPool = 0;

            //Act
            var result = await _bonusPoolService.Calculate(bonusPool, salary, totalSalary);

            //Assert
            Assert.AreEqual(0, result);
        }

        [Test]
        public async System.Threading.Tasks.Task CalculateBonus_650000TS50000S150000B_Return11538()
        {
            //Arrange
            int totalSalary = 650000;
            int salary = 50000;
            int bonusPool = 150000;

            //Act
            var result = await _bonusPoolService.Calculate(bonusPool, salary, totalSalary);

            //Assert
            Assert.AreEqual(11538, result);
        }
    }
}